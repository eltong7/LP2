﻿namespace Pmenus
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exercícioF2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciof3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciof4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exerciciof4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fSairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercícioF2ToolStripMenuItem,
            this.exercíciof3ToolStripMenuItem,
            this.exercíciof4ToolStripMenuItem,
            this.exerciciof4ToolStripMenuItem,
            this.fSairToolStripMenuItem});
            this.menuStrip1.Name = "menuStrip1";
            // 
            // exercícioF2ToolStripMenuItem
            // 
            resources.ApplyResources(this.exercícioF2ToolStripMenuItem, "exercícioF2ToolStripMenuItem");
            this.exercícioF2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem});
            this.exercícioF2ToolStripMenuItem.Name = "exercícioF2ToolStripMenuItem";
            this.exercícioF2ToolStripMenuItem.Click += new System.EventHandler(this.exercícioF2ToolStripMenuItem_Click);
            // 
            // copiarToolStripMenuItem
            // 
            resources.ApplyResources(this.copiarToolStripMenuItem, "copiarToolStripMenuItem");
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // colarToolStripMenuItem
            // 
            resources.ApplyResources(this.colarToolStripMenuItem, "colarToolStripMenuItem");
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            // 
            // exercíciof3ToolStripMenuItem
            // 
            resources.ApplyResources(this.exercíciof3ToolStripMenuItem, "exercíciof3ToolStripMenuItem");
            this.exercíciof3ToolStripMenuItem.Name = "exercíciof3ToolStripMenuItem";
            this.exercíciof3ToolStripMenuItem.Click += new System.EventHandler(this.exercíciof3ToolStripMenuItem_Click);
            // 
            // exercíciof4ToolStripMenuItem
            // 
            resources.ApplyResources(this.exercíciof4ToolStripMenuItem, "exercíciof4ToolStripMenuItem");
            this.exercíciof4ToolStripMenuItem.Name = "exercíciof4ToolStripMenuItem";
            this.exercíciof4ToolStripMenuItem.Click += new System.EventHandler(this.exercíciof4ToolStripMenuItem_Click);
            // 
            // exerciciof4ToolStripMenuItem
            // 
            resources.ApplyResources(this.exerciciof4ToolStripMenuItem, "exerciciof4ToolStripMenuItem");
            this.exerciciof4ToolStripMenuItem.Name = "exerciciof4ToolStripMenuItem";
            this.exerciciof4ToolStripMenuItem.Click += new System.EventHandler(this.exerciciof4ToolStripMenuItem_Click);
            // 
            // fSairToolStripMenuItem
            // 
            resources.ApplyResources(this.fSairToolStripMenuItem, "fSairToolStripMenuItem");
            this.fSairToolStripMenuItem.Name = "fSairToolStripMenuItem";
            this.fSairToolStripMenuItem.Click += new System.EventHandler(this.fSairToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorToolStripMenuItem,
            this.calculadoraToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            // 
            // editorToolStripMenuItem
            // 
            resources.ApplyResources(this.editorToolStripMenuItem, "editorToolStripMenuItem");
            this.editorToolStripMenuItem.Name = "editorToolStripMenuItem";
            // 
            // calculadoraToolStripMenuItem
            // 
            resources.ApplyResources(this.calculadoraToolStripMenuItem, "calculadoraToolStripMenuItem");
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            // 
            // FrmPrincipal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmPrincipal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exercícioF2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciof3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciof4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exerciciof4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fSairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;

    }
}

