﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatriculaH = new System.Windows.Forms.TextBox();
            this.txtNomeH = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNumeroHoras = new System.Windows.Forms.TextBox();
            this.txtNumFaltas = new System.Windows.Forms.TextBox();
            this.txtDataEntradaH = new System.Windows.Forms.TextBox();
            this.lblMatriculaH = new System.Windows.Forms.Label();
            this.lblNomeH = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNumHorasH = new System.Windows.Forms.Label();
            this.lblDataEntradaH = new System.Windows.Forms.Label();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.btnInstanciarH = new System.Windows.Forms.Button();
            this.gpxHomeOfficeH = new System.Windows.Forms.GroupBox();
            this.rbtnNaoH = new System.Windows.Forms.RadioButton();
            this.rbtnSimH = new System.Windows.Forms.RadioButton();
            this.gpxHomeOfficeH.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatriculaH
            // 
            this.txtMatriculaH.Location = new System.Drawing.Point(163, 87);
            this.txtMatriculaH.Name = "txtMatriculaH";
            this.txtMatriculaH.Size = new System.Drawing.Size(214, 20);
            this.txtMatriculaH.TabIndex = 0;
            // 
            // txtNomeH
            // 
            this.txtNomeH.Location = new System.Drawing.Point(163, 113);
            this.txtNomeH.Name = "txtNomeH";
            this.txtNomeH.Size = new System.Drawing.Size(214, 20);
            this.txtNomeH.TabIndex = 1;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(163, 139);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(214, 20);
            this.txtSalarioHora.TabIndex = 2;
            // 
            // txtNumeroHoras
            // 
            this.txtNumeroHoras.Location = new System.Drawing.Point(163, 165);
            this.txtNumeroHoras.Name = "txtNumeroHoras";
            this.txtNumeroHoras.Size = new System.Drawing.Size(214, 20);
            this.txtNumeroHoras.TabIndex = 3;
            // 
            // txtNumFaltas
            // 
            this.txtNumFaltas.Location = new System.Drawing.Point(163, 217);
            this.txtNumFaltas.Name = "txtNumFaltas";
            this.txtNumFaltas.Size = new System.Drawing.Size(214, 20);
            this.txtNumFaltas.TabIndex = 4;
            // 
            // txtDataEntradaH
            // 
            this.txtDataEntradaH.Location = new System.Drawing.Point(163, 191);
            this.txtDataEntradaH.Name = "txtDataEntradaH";
            this.txtDataEntradaH.Size = new System.Drawing.Size(214, 20);
            this.txtDataEntradaH.TabIndex = 5;
            // 
            // lblMatriculaH
            // 
            this.lblMatriculaH.AutoSize = true;
            this.lblMatriculaH.Location = new System.Drawing.Point(28, 90);
            this.lblMatriculaH.Name = "lblMatriculaH";
            this.lblMatriculaH.Size = new System.Drawing.Size(52, 13);
            this.lblMatriculaH.TabIndex = 6;
            this.lblMatriculaH.Text = "Matrícula";
            // 
            // lblNomeH
            // 
            this.lblNomeH.AutoSize = true;
            this.lblNomeH.Location = new System.Drawing.Point(28, 116);
            this.lblNomeH.Name = "lblNomeH";
            this.lblNomeH.Size = new System.Drawing.Size(35, 13);
            this.lblNomeH.TabIndex = 7;
            this.lblNomeH.Text = "Nome";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(28, 142);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(83, 13);
            this.lblSalarioHora.TabIndex = 8;
            this.lblSalarioHora.Text = "Salário por Hora";
            // 
            // lblNumHorasH
            // 
            this.lblNumHorasH.AutoSize = true;
            this.lblNumHorasH.Location = new System.Drawing.Point(28, 168);
            this.lblNumHorasH.Name = "lblNumHorasH";
            this.lblNumHorasH.Size = new System.Drawing.Size(90, 13);
            this.lblNumHorasH.TabIndex = 9;
            this.lblNumHorasH.Text = "Número de Horas";
            // 
            // lblDataEntradaH
            // 
            this.lblDataEntradaH.AutoSize = true;
            this.lblDataEntradaH.Location = new System.Drawing.Point(28, 194);
            this.lblDataEntradaH.Name = "lblDataEntradaH";
            this.lblDataEntradaH.Size = new System.Drawing.Size(129, 13);
            this.lblDataEntradaH.TabIndex = 10;
            this.lblDataEntradaH.Text = "Data Entrada na Empresa";
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Location = new System.Drawing.Point(28, 220);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(74, 13);
            this.lblDiasFalta.TabIndex = 11;
            this.lblDiasFalta.Text = "Dias de Faltas";
            // 
            // btnInstanciarH
            // 
            this.btnInstanciarH.Location = new System.Drawing.Point(217, 281);
            this.btnInstanciarH.Name = "btnInstanciarH";
            this.btnInstanciarH.Size = new System.Drawing.Size(102, 23);
            this.btnInstanciarH.TabIndex = 12;
            this.btnInstanciarH.Text = "Instanciar Horista";
            this.btnInstanciarH.UseVisualStyleBackColor = true;
            this.btnInstanciarH.Click += new System.EventHandler(this.btnInstanciarH_Click);
            // 
            // gpxHomeOfficeH
            // 
            this.gpxHomeOfficeH.Controls.Add(this.rbtnSimH);
            this.gpxHomeOfficeH.Controls.Add(this.rbtnNaoH);
            this.gpxHomeOfficeH.Location = new System.Drawing.Point(433, 110);
            this.gpxHomeOfficeH.Name = "gpxHomeOfficeH";
            this.gpxHomeOfficeH.Size = new System.Drawing.Size(154, 120);
            this.gpxHomeOfficeH.TabIndex = 13;
            this.gpxHomeOfficeH.TabStop = false;
            this.gpxHomeOfficeH.Text = "Trabalha em Home Office?";
            // 
            // rbtnNaoH
            // 
            this.rbtnNaoH.AutoSize = true;
            this.rbtnNaoH.Location = new System.Drawing.Point(7, 20);
            this.rbtnNaoH.Name = "rbtnNaoH";
            this.rbtnNaoH.Size = new System.Drawing.Size(45, 17);
            this.rbtnNaoH.TabIndex = 0;
            this.rbtnNaoH.TabStop = true;
            this.rbtnNaoH.Text = "Não";
            this.rbtnNaoH.UseVisualStyleBackColor = true;
            // 
            // rbtnSimH
            // 
            this.rbtnSimH.AutoSize = true;
            this.rbtnSimH.Location = new System.Drawing.Point(7, 43);
            this.rbtnSimH.Name = "rbtnSimH";
            this.rbtnSimH.Size = new System.Drawing.Size(42, 17);
            this.rbtnSimH.TabIndex = 1;
            this.rbtnSimH.TabStop = true;
            this.rbtnSimH.Text = "Sim";
            this.rbtnSimH.UseVisualStyleBackColor = true;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 361);
            this.Controls.Add(this.gpxHomeOfficeH);
            this.Controls.Add(this.btnInstanciarH);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.lblDataEntradaH);
            this.Controls.Add(this.lblNumHorasH);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNomeH);
            this.Controls.Add(this.lblMatriculaH);
            this.Controls.Add(this.txtDataEntradaH);
            this.Controls.Add(this.txtNumFaltas);
            this.Controls.Add(this.txtNumeroHoras);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNomeH);
            this.Controls.Add(this.txtMatriculaH);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gpxHomeOfficeH.ResumeLayout(false);
            this.gpxHomeOfficeH.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatriculaH;
        private System.Windows.Forms.TextBox txtNomeH;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNumeroHoras;
        private System.Windows.Forms.TextBox txtNumFaltas;
        private System.Windows.Forms.TextBox txtDataEntradaH;
        private System.Windows.Forms.Label lblMatriculaH;
        private System.Windows.Forms.Label lblNomeH;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNumHorasH;
        private System.Windows.Forms.Label lblDataEntradaH;
        private System.Windows.Forms.Label lblDiasFalta;
        private System.Windows.Forms.Button btnInstanciarH;
        private System.Windows.Forms.GroupBox gpxHomeOfficeH;
        private System.Windows.Forms.RadioButton rbtnSimH;
        private System.Windows.Forms.RadioButton rbtnNaoH;
    }
}