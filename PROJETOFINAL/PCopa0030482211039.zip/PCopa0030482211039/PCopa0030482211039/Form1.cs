﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211039
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

            try
            { 
            // aqui a conexão vai depende da sua máquina da escola ou particular 
            conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=LP2;User ID=BD2211039;PASSWORD=Santos22*"); 
            conexao.Open(); 
            } 
            catch (SqlException ex) 
            { 
                MessageBox.Show("Erro de banco de dados =/" + ex.Message); 
            }
            catch (Exception ex) 
            { 
                MessageBox.Show("Outros Erros =/" + ex.Message); 
            }
        }

        private void jogosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["FrmSobre"];
            if (fc != null)
                fc.Close();

            FrmSobre objJ = new FrmSobre();
            objJ.MdiParent = this;
            objJ.WindowState = FormWindowState.Maximized;
            objJ.Show();
        }

        private void cadastroDeJogosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmJogos"];
            if (fc != null)
                fc.Close();

            frmJogos objJ = new frmJogos();
            objJ.MdiParent = this;
            objJ.WindowState = FormWindowState.Maximized;
            objJ.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
